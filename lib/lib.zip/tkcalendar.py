import os
import json
from tkinter import Tk, StringVar
from tkinter.ttk import Combobox, Button, Label

from config.setting import ico


class fileJSON(object):
    # noinspection PyPep8Naming
    def __init__(self):
        data_json = {
            "begin": '',
            "end": ''
        }

        self.json_file = "time.json"
        if os.path.isfile(self.json_file) is False:
            with open(self.json_file, 'w', encoding="utf-8") as f:
                f.write(json.dumps(data_json, indent=4, ensure_ascii=False))

    def upgrade_value(self, root, value):
        """
        root: 预更改的键
        value：预更改的值
        """
        if os.path.isfile(self.json_file) is True:
            with open(self.json_file, 'r', encoding="utf-8") as f:
                data_json = dict(json.loads(f.read()))
            data_json[root] = value
            with open(self.json_file, 'w', encoding="utf-8") as f:
                f.write(json.dumps(data_json, indent=4, ensure_ascii=False))

    def read_time(self, root):
        if os.path.isfile(self.json_file) is True:
            with open(self.json_file, 'r', encoding="utf-8") as f:
                data_json = dict(json.loads(f.read()))
        return data_json[root]


def create_json(key, value):
    fileJSON().upgrade_value(key, value)


class drop_menu(object):
    """
    下拉框自动生成
    """

    def __init__(self, root):
        self._root = root
        self._width = 60
        self._height = 30
        self.ComBoxList = None

    def handle(self, *args):  # 处理事件
        with open('begin_time', 'a+', encoding='utf-8') as f:
            f.write(self.ComBoxList.get())
        with open('begin_time', 'r', encoding='utf-8') as f:
            str_time = f.read()

        create_json('begin', str_time)

    def new(self, x, y, begin, end):
        """
        x,y是定位
        begin,end是列表元素范围
        add是绑定
        """
        comvalue = StringVar()
        self.ComBoxList = Combobox(self._root, textvariable=comvalue, state='readonly')  # 初始化
        v_list = []
        for n in range(begin, end):
            if n in [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]:  # 使用24小时
                v_list.append('{}{}'.format(0, n))
            else:
                v_list.append(n)
        self.ComBoxList["values"] = tuple(v_list)
        self.ComBoxList.current(0)  # 选择第一个元素
        self.ComBoxList.bind("<<ComboboxSelected>>", self.handle)  # 绑定事件,(下拉列表框被选中时，绑定handle()函数)
        self.ComBoxList.place(relx=x, rely=y, width=self._width, height=self._height)

    @staticmethod
    def clean():
        # time_file = ['begin_time.txt', 'end_time.txt']
        if os.path.isfile('begin_time') is True:
            os.remove('begin_time')


class Calendar(object):
    def __init__(self):
        self._width = 350
        self._height = 200
        self._win = Tk()
        self._win.title('开始时间')
        self._win.iconbitmap(ico)

        # 居中
        screenwidth = self._win.winfo_screenwidth()
        screenheight = self._win.winfo_screenheight()
        aligner = '%dx%d+%d+%d' % (
            self._width, self._height, (screenwidth - self._width) / 2, (screenheight - self._height) / 2)
        self._win.geometry(aligner)

    def _exit(self):
        self._win.quit()

    def _get_value(self):
        self._win.quit()

    def list_value(self):
        # 下拉框布局
        # menu = drop_menu(self._win)
        drop_menu(self._win).new(0.1, 0.1, 2020, 2099)  # 年
        drop_menu(self._win).new(0.4, 0.1, 1, 13)  # 月
        drop_menu(self._win).new(0.7, 0.1, 1, 32)  # 日
        drop_menu(self._win).new(0.1, 0.3, 1, 25)  # 时
        drop_menu(self._win).new(0.4, 0.3, 0, 60)  # 分
        drop_menu(self._win).new(0.7, 0.3, 0, 61)  # 秒

    def window(self):
        # 文字按钮布局
        Label(text='年').place(relx=0.28, rely=0.1, width=30, height=30)
        Label(text='月').place(relx=0.58, rely=0.1, width=30, height=30)
        Label(text='日').place(relx=0.88, rely=0.1, width=30, height=30)
        Label(text='时').place(relx=0.28, rely=0.3, width=30, height=30)
        Label(text='分').place(relx=0.58, rely=0.3, width=30, height=30)
        Label(text='秒').place(relx=0.88, rely=0.3, width=30, height=30)
        Button(self._win, text='确定', command=self._get_value).place(relx=0.12, rely=0.75, width=80, height=30)
        Button(self._win, text='取消', command=self._exit).place(relx=0.56, rely=0.75, width=80, height=30)
        self._win.mainloop()


def begin_time():
    c = Calendar()
    c.list_value()
    c.window()


if __name__ == '__main__':
    begin_time()
